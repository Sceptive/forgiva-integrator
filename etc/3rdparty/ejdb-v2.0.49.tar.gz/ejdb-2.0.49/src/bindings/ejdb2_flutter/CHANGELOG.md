## 1.0.22+1

  * Upgraded to ejdb v2.0.48 (Support of collection Joins)

## 1.0.21+1

  * Upgraded to ejdb v2.0.47

## 1.0.20+1

  * Upgraded to ejdb v2.0.46

## 1.0.19+1

  * Upgraded to ejdb v2.0.45

## 1.0.18+1

  * Upgraded to ejdb v2.0.44

## 1.0.17+1

  * Upgraded to ejdb v2.0.43

## 1.0.16+1

  * Upgraded to ejdb v2.0.42

## 1.0.15+1

  * Upgraded to ejdb v2.0.41

## 1.0.14+2

  * Readme updated

## 1.0.14+1

  * Upgraded to ejdb v2.0.40

## 1.0.13+1

  * Upgraded to ejdb v2.0.39

## 1.0.12+1

  * Upgraded to ejdb v2.0.37
  * Fixed wal related durability issue

## 1.0.11+2

* Readme updated

## 1.0.11+1

* Added iOS support
* Upgraded to ejdb v2.0.36

## 1.0.10+1

* Fixed JQL apply ignores value set by placeholder #269

## 1.0.9+1

* Reduced library size by 400K: stripped off unused utf8proc data

## 1.0.8+1

* Added `patchOrPut()`

## 1.0.7+1

* Added `delIgnoreNotFound()`

## 1.0.6+1

* Upgraded to ejdb v2.0.32

## 1.0.5+1

* Upgraded to ejdb v2.0.31

## 1.0.4+1

* Added `EJDB2#getOptional` for convenience

## 1.0.3+1

* Removed depenedency for eclipse generator plugin

## 1.0.2+1

* Upgraded to ejdb v2.0.30

## 1.0.1+1

* Minors: eliminated unchecked cast warning

## 1.0.0+2

* Initial release
