import 'package:flutter_driver/driver_extension.dart';
import 'package:ejdb2_example/main.dart' as app;

void main() {
  enableFlutterDriverExtension();
  app.main();
}
