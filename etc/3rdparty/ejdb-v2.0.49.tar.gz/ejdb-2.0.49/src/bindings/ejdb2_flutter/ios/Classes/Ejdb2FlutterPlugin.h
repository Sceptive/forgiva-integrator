#import <Flutter/Flutter.h>

@interface Ejdb2FlutterPlugin : NSObject<FlutterPlugin>
@end
